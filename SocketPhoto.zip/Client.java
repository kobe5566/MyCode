//**************/
//
// client 接圖片
//
//**************/


import java.awt.BorderLayout;  
import java.awt.Graphics;  
import java.awt.event.ActionEvent;  
import java.awt.event.ActionListener;  
import java.awt.image.BufferedImage;  
import java.io.ByteArrayInputStream;  
import java.io.ByteArrayOutputStream;  
import java.io.DataInputStream;  
import java.io.File;  
import java.io.PrintWriter;  
import java.net.Socket;  
  
import javax.imageio.ImageIO;  
import javax.swing.JButton;  
import javax.swing.JFrame;  
import javax.swing.JPanel;  
  
public class Client extends JFrame {  
	
	/*****創GUI*****/
	JButton button;  
    JPanel panel;  
    int count = 0;  
    
    /*****image存圖片*****/
    BufferedImage image ; 
    
    public Client() {
    	
        setSize(300, 400);  
        button = new JButton("獲取圖像");  
        add(button,BorderLayout.NORTH);  
        button.addActionListener(new ActionListener() {  
            
        	
        public void actionPerformed(ActionEvent event) {  
                
        	try {  
                	System.out.println("準備連線");
                							//用ifconfig查
                    Socket s = new Socket("192.168.1.105",7789);  
                    System.out.println("連線成功");
                    
                    //
                    DataInputStream in = new DataInputStream(s.getInputStream());  
                    
                    //b用來存圖片轉成byte data
                    byte[]b = new byte[1024];
                    
                    //bout存 byte type的outputstream
                    ByteArrayOutputStream bout = new ByteArrayOutputStream();  
                    
                    int length = 0;  
                    //read(b) 從inputStream讀取存到(byte)b stream內沒東西可讀=-1
                    //write(b,x,y) 將(byte)b中以偏移量x開始的y個字符輸出到outputstream
                    while((length=in.read(b))!=-1) bout.write(b, 0, length);  
                    
                    //bin存 byte type的inputstream
                    ByteArrayInputStream bin = new ByteArrayInputStream(bout.toByteArray());  
                    image = ImageIO.read(bin);  
                    repaint();  
                    
                    //存圖片
                    ImageIO.write(image, "jpg", new File("output-"+count+".jpg"));  
                    
                    count++;  
                    s.close();  
                } catch (Exception e) {  
                }  
            }  
        });  
        panel = new JPanel();  
        add(panel);  
    }  
    /*******panel上印圖片*******/
    @Override  
    public void paint(Graphics g){  
        super.paint(g);  
        						//x y 寬 高
        g.drawImage(image, 100, 100, 100, 100, null);//image为BufferedImage类型  
    }  
    public static void main(String[] args) throws Exception {  
        Client frame = new Client();  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        frame.setVisible(true);  
    }  
  
}  
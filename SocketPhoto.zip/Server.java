//**************/
//
// server 傳圖片
//
//**************/

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.net.ServerSocket;
import java.net.Socket;

import javax.imageio.ImageIO;

public class Server {

	public static void main(String[] args) throws Exception {
		
		ServerSocket server = new ServerSocket(5555);
		Socket s = server.accept();
		System.out.println("成功連線!");
		
		while(true){
			System.out.println("開始傳送圖片");
			DataOutputStream dout = new DataOutputStream(s.getOutputStream());
			
			BufferedImage image = ImageIO.read(new File("test.jpg"));
			
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			
			//把image存到out (byte的outputstream)
			ImageIO.write(image, "jpg", out);
			//out轉成b(byte)
			byte[] b = out.toByteArray();
			
			//b寫進dout(實際要傳的outputstream)
			dout.write(b);
			s.close();
			
			System.out.println("圖片傳送完成! 重新連接" );
			
			s = server.accept();
			
		}
	}
}
